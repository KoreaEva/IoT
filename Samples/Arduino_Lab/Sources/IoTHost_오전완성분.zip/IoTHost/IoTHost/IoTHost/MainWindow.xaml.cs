﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.IO.Ports;
using System.Windows.Threading;

namespace IoTHost
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DispatcherTimer timer = new DispatcherTimer();
        private static SerialPort ComPort = new SerialPort();
        private static string ConsoleResult;
        private static string ConsoleTemp;

        private static string Sensor1;
        private static string Sensor2;
        private static string Sensor3;


        public MainWindow()
        {
            InitializeComponent();

            timer.Interval = new TimeSpan(0, 0, 0, 3);
            timer.Tick += Timer_Tick;

            ComPort.DataReceived += ComPort_DataReceived;
        }

        private void ComPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            string result = ComPort.ReadExisting();

            ConsoleTemp += result;


            //[S?:?] 내용을 추출하기 위한 부분
            while (true)
            {
                int startPoint = ConsoleTemp.IndexOf('[');
                if (startPoint == -1)
                    break;

                int endPoint = ConsoleTemp.IndexOf(']');
                if (endPoint == -1)
                    break;

                string temp = ConsoleTemp.Substring(startPoint + 1, endPoint - startPoint - 1);

                string[] data = temp.Split(':');

                switch (data[0])
                {
                    case "S1":
                        {
                            Sensor1 = data[1];
                            break;
                        }
                    case "S2":
                        {
                            Sensor2 = data[1];
                            break;
                        }
                    case "S3":
                        {
                            Sensor3 = data[1];
                            break;
                        }
                    case "NT":
                        {

                            break;
                        }
                }

                ConsoleTemp = ConsoleTemp.Replace('\n', '^');
                ConsoleTemp = ConsoleTemp.Replace('\r', '^');

                if (ConsoleTemp.Length == endPoint)
                    ConsoleTemp = "";
                else
                {
                    ConsoleTemp = ConsoleTemp.Substring(endPoint + 1, ConsoleTemp.Length - endPoint - 1);
                }
            }

            ConsoleResult += result;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            txtSystemConsole.Text = ConsoleResult;
            txtSystemConsole.ScrollToEnd();

            txtSensor1.Text = Sensor1;
            txtSensor2.Text = Sensor2;
            txtSensor3.Text = Sensor3;
        }

        private void btnConnection_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!ComPort.IsOpen)
                {
                    ComPort.PortName = (string)((ListBoxItem)lstPort.SelectedItem).Content;
                    ComPort.BaudRate = Int32.Parse(((ListBoxItem)lstSpeed.SelectedItem).Content.ToString());
                    ComPort.Open();
                    txtSystemConsole.Text = "";

                    btnConnection.Content = "아두이노 연결해제";

                    timer.Start();
                }
                else
                {
                    ComPort.Close();
                    btnConnection.Content = "아두이노 연결";

                    timer.Stop();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("접속에 문제가 있습니다. Port와 Speed를 확인해 주십시오\n" + ex.Message, "접속오류");
            }

        }
    }
}