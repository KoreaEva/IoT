﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace IoTService
{
    /// <summary>
    /// Summary description for Service
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class Service : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }

        [WebMethod]
        public string InsertSensorData(string s1, string s2, string s3)
        {
            string connectionString = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand("", connection);

            //Insert에 필요한 ID1, ID2를 만든다.
            //---------------------------------------------------------------------------------
            SqlParameter[] p1 = {
                                      new SqlParameter("@ID1",SqlDbType.Char,14),
                                 };

            string ID1 = DateTime.Now.ToString("yyyyMMddhhmmss");
            p1[0].Value = ID1;

            connection.Open();

            command.CommandText = "SELECT COUNT(*) + 1 FROM SensorData WHERE ID1 = @ID1";
            command.Parameters.Add(p1[0]);

            int ID2 = (int)command.ExecuteScalar();


            //Insert
            //---------------------------------------------------------------------------------
            SqlParameter[] p2 = {
                                    new SqlParameter("@ID1", SqlDbType.Char, 14),
                                    new SqlParameter("@ID2", SqlDbType.Int),
                                    new SqlParameter("@Sensor1", SqlDbType.VarChar, 100),
                                    new SqlParameter("@Sensor2", SqlDbType.VarChar, 100),
                                    new SqlParameter("@Sensor3", SqlDbType.VarChar, 100)
                                };

            p2[0].Value = ID1;
            p2[1].Value = ID2;

            if (s1 != null) p2[2].Value = s1;
            else p2[2].Value = "0";

            if (s2 != null) p2[3].Value = s2;
            else p2[3].Value = "0";

            if (s3 != null) p2[4].Value = s3;
            else p2[4].Value = "0";

            command.CommandText = "INSERT INTO dbo.SensorData(ID1, ID2, Sensor1, Sensor2, Sensor3, InsertTime) VALUES(@ID1, @ID2, @Sensor1, @Sensor2, @Sensor3, GETDATE())";
            command.Parameters.Clear();
            command.Parameters.Add(p2[0]);
            command.Parameters.Add(p2[1]);
            command.Parameters.Add(p2[2]);
            command.Parameters.Add(p2[3]);
            command.Parameters.Add(p2[4]);

            command.ExecuteNonQuery();

            connection.Close();

            return "OK";
        }

    }
}
